#!/bin/sh
#PBS -v PATH
#$ -v PATH


para=$1
cd /data5/data/webcomp/web-session/1618364548
./1618364548.fas.0.63117-bl.pl 0 $para &
./1618364548.fas.0.63117-bl.pl 1 $para &
./1618364548.fas.0.63117-bl.pl 2 $para &
./1618364548.fas.0.63117-bl.pl 3 $para &
wait

