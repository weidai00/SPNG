#!/bin/sh
#PBS -v PATH
#$ -v PATH


para=$1
cd /data5/data/webcomp/web-session/1618410241
./1618410241.fas.0.23242-bl.pl 0 $para &
./1618410241.fas.0.23242-bl.pl 1 $para &
./1618410241.fas.0.23242-bl.pl 2 $para &
./1618410241.fas.0.23242-bl.pl 3 $para &
wait

